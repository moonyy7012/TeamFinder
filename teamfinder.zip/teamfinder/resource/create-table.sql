CREATE SEQUENCE BOARD_SEQ
INCREMENT BY 1
START WITH 1
MINVALUE 1
NOCYCLE;

CREATE SEQUENCE TEAM_SEQ
INCREMENT BY 1
START WITH 1
MINVALUE 1
NOCYCLE;

CREATE SEQUENCE USER_SEQ
INCREMENT BY 1
START WITH 1
MINVALUE 1
NOCYCLE;

CREATE SEQUENCE COMMENT_SEQ
INCREMENT BY 1
START WITH 1
MINVALUE 1
NOCYCLE;

CREATE SEQUENCE REVIEW_SEQ
INCREMENT BY 1
START WITH 1
MINVALUE 1
NOCYCLE;

CREATE SEQUENCE MEMBER_SEQ
INCREMENT BY 1
START WITH 1
MINVALUE 1
NOCYCLE;

create table board(
post_id number not null primary key,
upload_time date not null,
title varchar(50) not null,
context varchar(500) not null,
region varchar(10) not null,
meeting_method varchar(10) not null,
team_image varchar(50),
user_index varchar(20) not null,
project_stack varchar(50)not null,
board_type number not null,
foreign key(user_index) references user_list(user_index)
);

create table team(
team_id number not null primary key,
post_id number not null,
max_person number not null,
leader_id number not null,
title varchar(50) not null,
status number not null,
foreign key(post_id) references board(post_id)
);

create table member_list(
member_id number not null primary key,
team_id number not null,
user_index number,
status number not null,
foreign key(team_id) references team(team_id)
);

create table user_list(
user_index number not null primary key,
user_pwd varchar(20) not null,
region varchar(20),
user_image varchar(50),
user_stack varchar(50),
uesr_email varchar(50) not null,
user_id varchar(10) not null
);

create table comment_board(
comment_id number not null primary key,
user_index number not null,
post_id number not null,
comment_text varchar(100) not null,
comment_type varchar(50) not null,
comment_class number not null,
comment_order number not null,
comment_group number not null,
foreign key(user_index) references user_list(user_index),
foreign key(post_id) references board(post_id)
);

create table review(
review_id number not null primary key,
post_id number not null,
target_user_number number not null,
review_text varchar2(100) not null,
review_star number not null,
foreign key(post_id) references team(post_id)
);


--삽입예시 insert into user_list values(USER_SEQ.NEXTVAL,'111','서울','puppy.jpg','스프링','mm@scom','abc');
