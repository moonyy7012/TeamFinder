/**
 * 
 */

window.onload = function() {//윈도우가 열리면
	document.getElementById("secession").onclick = function() {
		if(confirm("정말 탈퇴하시겠습니까?")==true){
			/**/
		}
		else{
			return false;
		}
		
	}
 

}




