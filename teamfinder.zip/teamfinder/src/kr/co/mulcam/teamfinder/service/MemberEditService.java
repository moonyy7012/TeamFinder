package kr.co.mulcam.teamfinder.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.co.mulcam.teamfinder.dao.UsersMapper;
import kr.co.mulcam.teamfinder.dto.User;


//이 파일에서 UsersMapper 객체 이용해 db에 데이터 넣고 빼는 동작 수행
@Service
public class MemberEditService {
	@Autowired
	private UsersMapper userMapper;
	
	
	
	@Transactional(readOnly = false)
	public int editMember(User user) throws RuntimeException{
		//회원가입을 하기위한 비지니스 로직이 있다면 처리!! 
		int returnValue = 0;
		
		
		try {
			
			returnValue =  userMapper.editMember(user);
		} catch (Exception e) {
			
			e.printStackTrace();
			returnValue =  0;
		}
		
//		if(true)
//			throw new RuntimeException();
		
		return returnValue;
	}

}
